# Görev (LAB 1 · Adım 5)

data/hastalar.csv dosyasını oku.

1. Satır ve kolon sayısını yazdır.
2. Yaş: ortalama ve medyan.
3. Cinsiyete göre yaş ortalaması (tablo).

## Kurallar
- Kod `analiz.py` dosyasına yazılsın, pandas ile.
- Her adıma yorum satırı.
- Çalıştır, çıktıyı göster.
