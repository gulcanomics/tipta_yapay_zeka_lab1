# Hafta 1 · LAB 1 başlangıç dosyaları

**Adım 1'de, `git init`'ten önce:** zip'i aç ve içindekileri (bu README, `task.md`, `data/`, `AGENTS.md`, `CLAUDE.md`) doğrudan `~/acu-ai/week1` klasörüne taşı. Ayrı bir alt klasörde kalmasınlar: agent kural dosyalarını, kod da `data/hastalar.csv` yolunu bu klasörde arar.

Kontrol: `cd ~/acu-ai/week1 && ls` → `AGENTS.md  CLAUDE.md  README.md  data  task.md` görmelisin.

| Dosya | Ne için |
|---|---|
| `task.md` | Adım 5: agent'a vereceğin görev |
| `data/hastalar.csv` | 40 sentetik hasta (gerçek veri değil) |
| `AGENTS.md` | Agent'ın kuralları. OpenCode, Codex ve Kilo bunu kendiliğinden okur |
| `CLAUDE.md` | Claude Code için: tek satır, `AGENTS.md`'yi çağırır |

Gemini CLI kendi `GEMINI.md` dosyasını okur; onu kullanıyorsan ilk mesajında "Önce AGENTS.md'yi oku" de.

Adımlar slaytlarda: Terminal → VS Code + venv → Git → agent → task.md.
