# Bu projede çalışan AI agent için kurallar

Bu dosyayı agent her oturumun başında okur. (Claude Code bu dosyayı CLAUDE.md üzerinden okur.)

## Bağlam
- Bu bir ders projesi. Kullanıcı kod yazmaya yeni başlıyor: her adımı kısa ve sade Türkçe ile açıkla.
- Veri sentetik. Gerçek hasta verisi bu klasöre asla konmaz.

## Sınırlar
- Sadece bu klasörün içinde çalış. Klasör dışındaki dosyalara dokunma.
- Dosya silmeden, `pip install` yapmadan ya da `git` geçmişini değiştirmeden önce sor.
- `sudo`, `rm -rf`, `git reset --hard`, `git push --force` kullanma.

## Kod
- Python + pandas. Kod okunaklı olsun; her adıma yorum satırı yaz.
- Kodu bu klasördeki sanal ortamla çalıştır: macOS `.venv/bin/python`, Windows `.venv/Scripts/python`. Sistemin Python'una paket kurma; gereken paketi önce sorup `.venv` içine kur.
- Bir şey hesapladığında sonucu kafadan söyleme: kodu çalıştır, çıktıyı göster.
- Veride satır atar, değer dönüştürür ya da doldurursan bunu sayısıyla raporla.
